
public class Volo {
	String destinazione;
	String compagniaAerea;
	boolean nazionale;
	boolean prenotato;

	Volo() {
	}

	Volo(String destinazione, String compagniaAerea, boolean nazionale, boolean prenotato) {
		this.destinazione = destinazione;
		this.compagniaAerea = compagniaAerea;
		this.nazionale = nazionale;
		this.prenotato = prenotato;
	}

	public String getDestinazione() {
		return destinazione;
	}

	public String getCompagniaAerea() {
		return compagniaAerea;
	}

	public boolean getNazionale() {
		return nazionale;
	}

	public boolean getPrenotato() {
		return prenotato;
	}

	void prenota() {

	}
}
