import java.util.*;

public class Main {

	public static void main(String[] args) {
		AgenziaViaggi a = new AgenziaViaggi();
		Scanner tastiera = new Scanner(System.in);
		int s = 0;
		do {
			System.out.println("Menu Contestuale:\r\n" + "1. Aggiungere un volo nazionale.\r\n"
					+ "2. Aggiungere un volo internazionale.\r\n" + "3. Visualizzare i voli nazionali disponibili.\r\n"
					+ "4. Visualizzare i voli internazionali disponibili.\r\n" + "5. Prenotare un volo.\r\n"
					+ "6. Annullare la prenotazione di un volo.\r\n" + "7. Uscire dall'applicazione.\r\n" + "");
			System.out.print(" Quale azione vuoi eseguire? ");
			s = tastiera.nextInt();
			switch (s) {
			case 1:
				a.aggiungiVoloManuale(true);
				break;
			case 2:
				a.aggiungiVoloManuale(false);
				break;
			case 3:
				a.visualizzaVoli(true);
				break;
			case 4:
				a.visualizzaVoli(false);
				break;
			case 5:
				a.prenotaVolo();
				break;
			case 6:
				a.cancellaPrenotazionevolo();
				break;
			case 7:
				System.out.println(" Uscita in corso... ");
				break;
			default:
				System.out.println(" Inserire una scelta tra quelle richieste");
			}
		} while (s != 7);
		System.out.println(" Uscita completata ");
		tastiera.close();
	}

}
