import java.util.*;;

public class AgenziaViaggi {
	ArrayList<Volo> lista = new ArrayList<Volo>();
	Scanner tastiera = new Scanner(System.in);

	public void aggiungiVolo(Volo volo) {
		lista.add(volo);
		System.out.println(" Volo aggiunto con successo! ");
	}

	public void aggiungiVoloManuale(boolean nazionale) {
		System.out.println(" Inserisci la destinazione ");
		String destinazione = tastiera.next();
		System.out.println("Inserisci la compagnia aerea ");
		String compagniaAerea = tastiera.next();
		Volo volo = new Volo(destinazione, compagniaAerea, nazionale, false);
		aggiungiVolo(volo);
	}

	public void visualizzaVoli(boolean nazionali) {
		boolean listavuota = true;
		if (nazionali == true) {
			int cnaz = 0;
			for (Volo i : lista) {
				if (i.getNazionale() == true) {
					cnaz++;
					listavuota = false;
					System.out.println(cnaz + " . " + "Destinazione : " + i.getDestinazione() + " Compagnia aerea: "
							+ i.getCompagniaAerea());
					if (i.getPrenotato() == true) {
						System.out.println(" Stato: prenotato ");
					} else {
						System.out.println("Stato: non prenotato");
					}
				}
			}
			if (listavuota == true) {
				System.out.println(
						" Impossibile visualizzare, non esiste nessun volo con le caratteristiche desiderate (nazionale). E' consigliabile aggiungerlo attraverso il menu contestuale");
			}
		} else {
			int cinternaz = 0;
			for (Volo i : lista) {
				cinternaz++;
				if (i.getNazionale() == false) {
					cinternaz++;
					listavuota = false;
					System.out.println(cinternaz + " . " + "Destinazione : " + i.getDestinazione()
							+ " Compagnia aerea: " + i.getCompagniaAerea());
					if (i.getPrenotato() == true) {
						System.out.println(" Stato: prenotato ");
					} else {
						System.out.println("Stato: non prenotato");
					}
				}
			}
			if (listavuota == true) {
				System.out.println(
						" Impossibile visualizzare, non esiste nessun volo con le caratteristiche desiderate (internazionale). E' consigliabile aggiungerlo attraverso il menu contestuale");
			}
		}

		System.out.println("\r\n" + "_________________________");
	}

	public void prenotaVolo() {
		if (lista.size() > 0) {
			int c = 0;
			for (Volo i : lista) {
				c++;
				System.out.println(c + " . " + " Destinazione : " + i.getDestinazione() + " Compagnia aerea: "
						+ i.getCompagniaAerea());
				if (i.getPrenotato() == true) {
					System.out.println(" Stato: prenotato ");
				} else {
					System.out.println("Stato: non prenotato");
				}
			}
			System.out.println(" Inserisci l'indice del volo che vuoi prenotare ");
			int i = tastiera.nextInt();
			if (lista.get(i - 1).getPrenotato() == true) {
				System.out.println(" Impossibile prenotare, il volo e' gia' prenotato");
			} else {
				lista.get(i - 1).prenotato = true;
				System.out.println(" Prenotazione effettuata correttamente ");
			}

		} else {
			System.out.println(" Nessun volo disponibile, e' necessario aggiungere un volo prima di prenotarlo ");
		}
	}

	public void cancellaPrenotazionevolo() {
		int c = 0;
		for (Volo i : lista) {
			c++;
			System.out.println(c + " . " + " Destinazione : " + i.getDestinazione() + " Compagnia aerea: "
					+ i.getCompagniaAerea());
			if (i.getPrenotato() == true) {
				System.out.println(" Stato: prenotato ");
			} else {
				System.out.println("Stato: non prenotato");
			}
		}
		System.out.println(" Inserisci l'indice del volo di cui vuoi cancellare prenotazione ");
		int i = tastiera.nextInt();
		if (lista.get(i - 1).getPrenotato() == false) {
			System.out.println(" Impossibile cancellare la prenotazione, il volo non risulta prenotato ");
		} else {
			System.out.println(" Cancellazzione effettuata correttamente ");
			lista.get(i - 1).prenotato = false;
		}

	}
}
